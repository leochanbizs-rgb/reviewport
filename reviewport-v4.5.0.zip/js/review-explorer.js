/*
 * ReviewPort Full Review Preview
 * Reads locally saved extension data only. This page never scrapes TikTok,
 * triggers pagination, solves verification, or sends review content externally.
 */

(() => {
    const PAGE_SIZE = 50;
    const csvExporter = new CSVExporter();

    let reviews = [];
    let sortedReviews = [];
    let visibleCount = PAGE_SIZE;
    let selectedReviewKey = null;
    let selectedPhotoIndex = 0;
    let savedState = { productHandle: 'tiktok-product', scrapingState: null, lastUpdated: '' };

    const elements = {
        refresh: document.getElementById('refreshReviews'),
        exportReviewPort: document.getElementById('exportReviewPort'),
        exportJudgeMe: document.getElementById('exportJudgeMe'),
        pausedBanner: document.getElementById('pausedBanner'),
        pausedMessage: document.getElementById('pausedMessage'),
        subtitle: document.getElementById('workspaceSubtitle'),
        scanContext: document.getElementById('scanContext'),
        summaryTotal: document.getElementById('summaryTotal'),
        summaryPhotos: document.getElementById('summaryPhotos'),
        summaryMultiPhotos: document.getElementById('summaryMultiPhotos'),
        summaryLowRated: document.getElementById('summaryLowRated'),
        sort: document.getElementById('sortReviews'),
        tableBody: document.getElementById('reviewTableBody'),
        tableStatus: document.getElementById('tableStatus'),
        loadMore: document.getElementById('loadMoreReviews'),
        detailEmpty: document.getElementById('detailEmpty'),
        detailContent: document.getElementById('detailContent'),
        detailReviewer: document.getElementById('detailReviewer'),
        detailRating: document.getElementById('detailRating'),
        detailDate: document.getElementById('detailDate'),
        detailSku: document.getElementById('detailSku'),
        detailText: document.getElementById('detailText'),
        closeDetails: document.getElementById('closeDetails'),
        mediaTitle: document.getElementById('mediaTitle'),
        mediaEmpty: document.getElementById('mediaEmpty'),
        mediaViewer: document.getElementById('mediaViewer'),
        mainPhoto: document.getElementById('mainPhoto'),
        imageUnavailable: document.getElementById('imageUnavailable'),
        originalPhotoLink: document.getElementById('openOriginalPhoto'),
        thumbnails: document.getElementById('photoThumbnails'),
        previousPhoto: document.getElementById('previousPhoto'),
        nextPhoto: document.getElementById('nextPhoto'),
        photoPosition: document.getElementById('photoPosition'),
        workspace: document.querySelector('.review-workspace')
    };

    elements.refresh.addEventListener('click', () => loadSavedReviews(true));
    elements.sort.addEventListener('change', () => {
        visibleCount = PAGE_SIZE;
        sortReviews();
        renderTable();
    });
    elements.loadMore.addEventListener('click', () => {
        visibleCount += PAGE_SIZE;
        renderTable();
    });
    elements.closeDetails.addEventListener('click', clearSelection);
    elements.previousPhoto.addEventListener('click', () => movePhoto(-1));
    elements.nextPhoto.addEventListener('click', () => movePhoto(1));
    elements.exportReviewPort.addEventListener('click', exportReviewPortCSV);
    elements.exportJudgeMe.addEventListener('click', exportJudgeMeCSV);
    document.addEventListener('keydown', handleKeyboardNavigation);

    loadSavedReviews(false);

    function loadSavedReviews(showRefreshState) {
        if (showRefreshState) {
            elements.refresh.disabled = true;
            elements.refresh.textContent = 'Refreshing…';
        }

        chrome.storage.local.get([
            'collectedReviews', 'processedReviews', 'scrapingState', 'lastUpdated',
            'productHandle', 'minStars', 'maxStars', 'onlyWithImages'
        ], (result) => {
            const preferred = Array.isArray(result.processedReviews) && result.processedReviews.length
                ? result.processedReviews
                : result.collectedReviews;

            reviews = Array.isArray(preferred) ? preferred.map(normalizeReview).filter(Boolean) : [];
            savedState = {
                scrapingState: result.scrapingState || null,
                lastUpdated: result.lastUpdated || '',
                productHandle: result.productHandle || 'tiktok-product',
                minStars: result.minStars || 1,
                maxStars: result.maxStars || 5,
                onlyWithImages: Boolean(result.onlyWithImages)
            };

            if (selectedReviewKey && !reviews.some(review => review.key === selectedReviewKey)) {
                selectedReviewKey = null;
            }

            visibleCount = Math.max(PAGE_SIZE, Math.min(visibleCount, reviews.length || PAGE_SIZE));
            sortReviews();
            updateHeader();
            updateSummary();
            renderTable();
            renderSelection();

            elements.refresh.disabled = false;
            elements.refresh.textContent = 'Refresh saved reviews';
        });
    }

    function normalizeReview(review) {
        if (!review || typeof review !== 'object') return null;
        const description = String(review.description || '').replace(/\s+/g, ' ').trim();
        const username = String(review.username || '').trim();
        const date = String(review.date || '').trim();
        const sku = String(review.sku || '').trim();
        const rating = Math.max(0, Math.min(5, parseInt(review.rating, 10) || 0));
        const key = String(review.review_id || `${username}::${date}::${sku}::${description.slice(0, 120)}`);
        return {
            ...review,
            key,
            username,
            description,
            sku,
            date,
            rating,
            photos: ReviewClassifier.photoUrls(review).filter(isSafeImageUrl)
        };
    }

    function isSafeImageUrl(value) {
        try {
            const url = new URL(value);
            return url.protocol === 'https:' || url.protocol === 'http:';
        } catch (_) {
            return false;
        }
    }

    function sortReviews() {
        const newestFirst = elements.sort.value === 'newest';
        sortedReviews = [...reviews].sort((a, b) => {
            if (!newestFirst && a.rating !== b.rating) return a.rating - b.rating;
            if (newestFirst) {
                const timeA = Date.parse(a.date) || 0;
                const timeB = Date.parse(b.date) || 0;
                if (timeA !== timeB) return timeB - timeA;
            }
            if (!newestFirst && a.rating === b.rating) {
                const timeA = Date.parse(a.date) || 0;
                const timeB = Date.parse(b.date) || 0;
                if (timeA !== timeB) return timeB - timeA;
            }
            return a.key.localeCompare(b.key);
        });
    }

    function updateHeader() {
        const total = reviews.length;
        elements.subtitle.textContent = total
            ? `${total} review${total === 1 ? '' : 's'} saved locally. Select a row to inspect the original review and buyer photos.`
            : 'No saved reviews yet. Open a TikTok Shop product page and run a ReviewPort scan.';

        const filters = `${savedState.minStars}–${savedState.maxStars} stars${savedState.onlyWithImages ? ' · photos only' : ''}`;
        const updated = savedState.lastUpdated ? `Last saved ${formatLocalTime(savedState.lastUpdated)}.` : 'No scan timestamp available.';
        elements.scanContext.textContent = total ? `${filters} · ${updated}` : 'Data stays in your browser until you export or clear it.';

        const paused = savedState.scrapingState && (savedState.scrapingState.status || savedState.scrapingState.state) === 'paused';
        elements.pausedBanner.hidden = !paused;
        if (paused) {
            elements.pausedMessage.textContent = savedState.scrapingState.message
                || 'Complete TikTok verification in the product page, then use Resume after verification from the ReviewPort popup.';
        }

        const hasReviews = total > 0;
        elements.exportReviewPort.disabled = !hasReviews;
        elements.exportJudgeMe.disabled = !hasReviews;
    }

    function updateSummary() {
        const summary = ReviewClassifier.summary(reviews);
        elements.summaryTotal.textContent = summary.total;
        elements.summaryPhotos.textContent = summary.photoReviews;
        elements.summaryMultiPhotos.textContent = summary.multiPhotoReviews;
        elements.summaryLowRated.textContent = summary.lowRated;
    }

    function renderTable() {
        elements.tableBody.replaceChildren();
        if (!sortedReviews.length) {
            const row = document.createElement('tr');
            row.className = 'empty-table';
            const cell = document.createElement('td');
            cell.colSpan = 6;
            cell.textContent = 'No saved reviews match the latest scan settings. Return to the ReviewPort popup to scan reviews.';
            row.appendChild(cell);
            elements.tableBody.appendChild(row);
            elements.tableStatus.textContent = 'No saved reviews.';
            elements.loadMore.hidden = true;
            return;
        }

        const rendered = sortedReviews.slice(0, visibleCount);
        const fragment = document.createDocumentFragment();
        rendered.forEach(review => fragment.appendChild(createReviewRow(review)));
        elements.tableBody.appendChild(fragment);

        const remaining = Math.max(0, sortedReviews.length - rendered.length);
        elements.tableStatus.textContent = remaining
            ? `Showing ${rendered.length} of ${sortedReviews.length} saved reviews.`
            : `Showing all ${sortedReviews.length} saved reviews.`;
        elements.loadMore.hidden = remaining === 0;
        if (remaining) elements.loadMore.textContent = `Load ${Math.min(PAGE_SIZE, remaining)} more reviews`;
    }

    function createReviewRow(review) {
        const row = document.createElement('tr');
        row.tabIndex = 0;
        row.dataset.reviewKey = review.key;
        row.setAttribute('aria-label', `Open details for review from ${review.username || 'unknown reviewer'} rated ${review.rating || 0} stars`);
        if (review.key === selectedReviewKey) row.classList.add('is-selected');
        row.addEventListener('click', () => selectReview(review.key));
        row.addEventListener('keydown', event => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                selectReview(review.key);
            }
        });

        row.appendChild(textCell(review.date || '—', 'review-date'));
        row.appendChild(textCell(review.username || '—', 'reviewer-name'));

        const ratingCell = document.createElement('td');
        const rating = document.createElement('span');
        rating.className = 'star-rating';
        rating.setAttribute('aria-label', `${review.rating} out of 5 stars`);
        rating.textContent = `${'★'.repeat(review.rating)}${'☆'.repeat(Math.max(0, 5 - review.rating))}`;
        const number = document.createElement('span');
        number.className = 'rating-number';
        number.textContent = String(review.rating || '—');
        rating.appendChild(number);
        ratingCell.appendChild(rating);
        row.appendChild(ratingCell);

        const skuCell = document.createElement('td');
        if (review.sku) {
            const sku = document.createElement('span');
            sku.className = 'sku-label';
            sku.title = review.sku;
            sku.textContent = review.sku;
            skuCell.appendChild(sku);
        } else {
            skuCell.appendChild(textCell('—', 'sku-empty').firstChild);
        }
        row.appendChild(skuCell);

        row.appendChild(textCell(review.description || 'No written review', 'review-excerpt'));

        const photoCell = document.createElement('td');
        const photoCount = document.createElement('span');
        photoCount.className = `photo-count${review.photos.length ? '' : ' no-photos'}`;
        photoCount.textContent = review.photos.length ? `${review.photos.length} photo${review.photos.length === 1 ? '' : 's'}` : '—';
        photoCell.appendChild(photoCount);
        row.appendChild(photoCell);
        return row;
    }

    function textCell(text, className) {
        const cell = document.createElement('td');
        const span = document.createElement('span');
        if (className) span.className = className;
        span.textContent = text;
        cell.appendChild(span);
        return cell;
    }

    function selectReview(key) {
        selectedReviewKey = key;
        selectedPhotoIndex = 0;
        renderTable();
        renderSelection();
    }

    function clearSelection() {
        selectedReviewKey = null;
        selectedPhotoIndex = 0;
        renderTable();
        renderSelection();
    }

    function selectedReview() {
        return reviews.find(review => review.key === selectedReviewKey) || null;
    }

    function renderSelection() {
        const review = selectedReview();
        const hasSelection = Boolean(review);
        elements.workspace.classList.toggle('has-selection', hasSelection);
        elements.detailEmpty.hidden = hasSelection;
        elements.detailContent.hidden = !hasSelection;
        if (!review) return;

        elements.detailReviewer.textContent = review.username || 'Unknown reviewer';
        elements.detailRating.textContent = `${'★'.repeat(review.rating)}${'☆'.repeat(Math.max(0, 5 - review.rating))} ${review.rating}/5`;
        elements.detailDate.textContent = review.date || 'No date';
        elements.detailSku.textContent = review.sku || 'No SKU recorded';
        elements.detailText.textContent = review.description || 'No written review was provided.';
        renderPhotos(review);
    }

    function renderPhotos(review) {
        const photos = review.photos;
        const hasPhotos = photos.length > 0;
        elements.mediaEmpty.hidden = hasPhotos;
        elements.mediaViewer.hidden = !hasPhotos;
        elements.photoPosition.hidden = !hasPhotos;
        elements.mediaTitle.textContent = hasPhotos
            ? `${photos.length} buyer photo${photos.length === 1 ? '' : 's'}`
            : 'No buyer photos';

        if (!hasPhotos) {
            elements.thumbnails.replaceChildren();
            return;
        }

        selectedPhotoIndex = Math.max(0, Math.min(selectedPhotoIndex, photos.length - 1));
        elements.photoPosition.textContent = `${selectedPhotoIndex + 1} / ${photos.length}`;
        elements.previousPhoto.disabled = selectedPhotoIndex === 0;
        elements.nextPhoto.disabled = selectedPhotoIndex === photos.length - 1;
        renderThumbnailStrip(review);
        loadMainPhoto(photos[selectedPhotoIndex], review, selectedPhotoIndex);
    }

    function renderThumbnailStrip(review) {
        const fragment = document.createDocumentFragment();
        review.photos.forEach((url, index) => {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = `thumbnail-button${index === selectedPhotoIndex ? ' is-active' : ''}`;
            button.setAttribute('aria-label', `View buyer photo ${index + 1} of ${review.photos.length}`);
            button.addEventListener('click', () => {
                selectedPhotoIndex = index;
                renderPhotos(review);
            });
            const img = document.createElement('img');
            img.src = url;
            img.alt = '';
            img.loading = 'lazy';
            img.referrerPolicy = 'no-referrer';
            img.addEventListener('error', () => {
                img.replaceWith(createThumbnailFallback());
            }, { once: true });
            button.appendChild(img);
            fragment.appendChild(button);
        });
        elements.thumbnails.replaceChildren(fragment);
    }

    function createThumbnailFallback() {
        const fallback = document.createElement('span');
        fallback.className = 'thumbnail-fallback';
        fallback.textContent = '—';
        return fallback;
    }

    function loadMainPhoto(url, review, index) {
        elements.imageUnavailable.hidden = true;
        elements.mainPhoto.hidden = false;
        elements.mainPhoto.alt = `Buyer photo ${index + 1} from ${review.username || 'reviewer'}`;
        elements.originalPhotoLink.href = url;
        elements.mainPhoto.onload = () => {
            elements.mainPhoto.hidden = false;
            elements.imageUnavailable.hidden = true;
        };
        elements.mainPhoto.onerror = () => {
            elements.mainPhoto.hidden = true;
            elements.imageUnavailable.hidden = false;
        };
        elements.mainPhoto.src = url;
    }

    function movePhoto(direction) {
        const review = selectedReview();
        if (!review || !review.photos.length) return;
        selectedPhotoIndex = Math.max(0, Math.min(review.photos.length - 1, selectedPhotoIndex + direction));
        renderPhotos(review);
    }

    function handleKeyboardNavigation(event) {
        const interactive = ['INPUT', 'TEXTAREA', 'SELECT'];
        if (interactive.includes(document.activeElement?.tagName)) return;
        if (event.key === 'ArrowLeft') movePhoto(-1);
        if (event.key === 'ArrowRight') movePhoto(1);
        if (event.key === 'Escape' && selectedReviewKey) clearSelection();
    }

    function exportReviewPortCSV() {
        if (!reviews.length) return;
        const filename = `reviewport_reviews_${fileTimestamp()}.csv`;
        csvExporter.exportToExplorerCSV(reviews, filename);
        announceExport(`Exported ${reviews.length} reviews in ReviewPort CSV format.`);
    }

    function exportJudgeMeCSV() {
        if (!reviews.length) return;
        const filename = `judge_me_reviews_${fileTimestamp()}.csv`;
        csvExporter.exportToJudgeMeCSV(reviews, filename, savedState.productHandle || 'tiktok-product');
        announceExport(`Exported ${reviews.length} reviews in Judge.me format.`);
    }

    function announceExport(message) {
        elements.scanContext.textContent = message;
        window.setTimeout(() => {
            if (reviews.length) updateHeader();
        }, 2500);
    }

    function fileTimestamp() {
        return new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    }

    function formatLocalTime(value) {
        const date = new Date(value);
        if (Number.isNaN(date.getTime())) return 'recently';
        return date.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
    }
})();
