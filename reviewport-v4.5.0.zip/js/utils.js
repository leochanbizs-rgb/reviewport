/**
 * ReviewPort local utilities.
 * All formatting and export work is performed in the browser. No review text is
 * sent to a translation, AI, or other third-party service.
 */

class ReviewFilter {
    filterByRating(reviews, minStars, maxStars) {
        return reviews.filter(review => {
            const rating = parseInt(review.rating, 10) || 0;
            return rating >= minStars && rating <= maxStars;
        });
    }

    filterByImages(reviews, onlyWithImages) {
        if (!onlyWithImages) return reviews;
        return reviews.filter(review => ReviewClassifier.photoUrls(review).length > 0);
    }

    applyFilters(reviews, options = {}) {
        const byRating = this.filterByRating(reviews, options.minStars || 1, options.maxStars || 5);
        return this.filterByImages(byRating, Boolean(options.onlyWithImages));
    }
}

class ReviewClassifier {
    static photoUrls(review) {
        return String(review.photo_urls || '')
            .split(' | ')
            .map(url => url.trim())
            .filter(url => Boolean(url) && url !== 'N/A');
    }

    static ratingCategory(rating) {
        const value = parseInt(rating, 10) || 0;
        if (value === 5) return '5 stars - Excellent';
        if (value === 4) return '4 stars - Good';
        if (value === 3) return '3 stars - Mixed';
        if (value >= 1) return '1-2 stars - Needs attention';
        return 'No rating';
    }

    static photoCategory(photoCount) {
        if (photoCount === 0) return 'No photos';
        if (photoCount === 1) return '1 photo';
        if (photoCount <= 3) return '2-3 photos';
        return '4+ photos';
    }

    static metadata(review) {
        const photos = this.photoUrls(review);
        return {
            rating_category: this.ratingCategory(review.rating),
            review_type: photos.length ? 'Photo review' : 'Text review',
            has_photos: photos.length ? 'Yes' : 'No',
            photo_count: photos.length,
            photo_category: this.photoCategory(photos.length),
            photos
        };
    }

    static summary(reviews) {
        const counts = { total: reviews.length, photoReviews: 0, multiPhotoReviews: 0, lowRated: 0 };
        reviews.forEach(review => {
            const metadata = this.metadata(review);
            if (metadata.photo_count > 0) counts.photoReviews += 1;
            if (metadata.photo_count > 1) counts.multiPhotoReviews += 1;
            if ((parseInt(review.rating, 10) || 0) <= 2) counts.lowRated += 1;
        });
        return counts;
    }
}

class JudgeMeConverter {
    convertToJudgeMeFormat(reviews, productHandle = 'tiktok-product') {
        return reviews.map((review, index) => ({
            title: this.makeLocalTitle(review),
            body: review.description || '',
            rating: parseInt(review.rating, 10) || 5,
            review_date: this.formatDate(review.date),
            reviewer_name: review.username || 'Anonymous',
            reviewer_email: this.generateEmail(review.username, index),
            product_id: '',
            product_handle: productHandle,
            reply: '',
            picture_urls: ReviewClassifier.photoUrls(review).slice(0, 5).join(',')
        }));
    }

    makeLocalTitle(review) {
        const text = (review.description || '').replace(/\s+/g, ' ').trim();
        if (!text) return `${parseInt(review.rating, 10) || 5}-star review`;
        let title = text.split(/(?<=[.!?。！？])\s+/)[0] || text;
        title = title.replace(/[.。!！?？,，;；:：]+$/, '').trim();
        if (title.length > 60) {
            title = title.slice(0, 60);
            const lastSpace = title.lastIndexOf(' ');
            if (lastSpace > 20) title = title.slice(0, lastSpace);
        }
        return title || `${parseInt(review.rating, 10) || 5}-star review`;
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        const safeDate = Number.isNaN(date.getTime()) ? new Date() : date;
        return `${safeDate.toISOString().replace('T', ' ').slice(0, 19)} UTC`;
    }

    generateEmail(username, index) {
        const cleanUsername = (username || '').replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || `user${index + 1}`;
        return `${cleanUsername}@reviewport.local`;
    }
}

class CSVExporter {
    escapeCSVField(value) {
        let stringValue = String(value ?? '');
        // Prevent spreadsheet formula interpretation when a CSV is opened.
        if (/^[=+\-@]/.test(stringValue)) stringValue = `'${stringValue}`;
        if (/[",\n\r]/.test(stringValue)) return `"${stringValue.replace(/"/g, '""')}"`;
        return stringValue;
    }

    exportToCSV(reviews, filename = 'reviewport_reviews.csv') {
        if (!Array.isArray(reviews) || !reviews.length) throw new Error('No reviews available to export.');
        const headers = ['username', 'rating', 'description', 'sku', 'date', 'photo_urls'];
        this.downloadCSV(this.toCsv(headers, reviews), filename);
    }

    exportToExplorerCSV(reviews, filename = 'reviewport_csv_explorer.csv') {
        if (!Array.isArray(reviews) || !reviews.length) throw new Error('No reviews available to export.');

        const maxPhotoCount = Math.max(0, ...reviews.map(review => ReviewClassifier.photoUrls(review).length));
        const photoHeaders = Array.from({ length: maxPhotoCount }, (_, index) => `photo_url_${index + 1}`);
        const headers = [
            'username', 'rating', 'rating_category', 'review_type',
            'has_photos', 'photo_count', 'photo_category',
            'description', 'sku', 'date', ...photoHeaders
        ];

        const rows = reviews.map(review => {
            const metadata = ReviewClassifier.metadata(review);
            const row = {
                username: review.username || '',
                rating: parseInt(review.rating, 10) || '',
                rating_category: metadata.rating_category,
                review_type: metadata.review_type,
                has_photos: metadata.has_photos,
                photo_count: metadata.photo_count,
                photo_category: metadata.photo_category,
                description: review.description || '',
                sku: review.sku || '',
                date: review.date || ''
            };
            photoHeaders.forEach((header, index) => {
                row[header] = metadata.photos[index] || '';
            });
            return row;
        });

        this.downloadCSV(this.toCsv(headers, rows), filename);
    }

    exportToJudgeMeCSV(reviews, filename = 'judge_me_reviews.csv', productHandle = 'tiktok-product') {
        if (!Array.isArray(reviews) || !reviews.length) throw new Error('No reviews available to export.');
        const headers = ['title', 'body', 'rating', 'review_date', 'reviewer_name', 'reviewer_email', 'product_id', 'product_handle', 'reply', 'picture_urls'];
        const rows = new JudgeMeConverter().convertToJudgeMeFormat(reviews, productHandle);
        this.downloadCSV(this.toCsv(headers, rows), filename);
    }

    toCsv(headers, rows) {
        return [headers.join(','), ...rows.map(row => headers.map(header => this.escapeCSVField(row[header])).join(','))].join('\n');
    }

    downloadCSV(csvContent, filename) {
        const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = filename;
        link.style.display = 'none';
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
    }
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { ReviewFilter, ReviewClassifier, CSVExporter, JudgeMeConverter };
}
