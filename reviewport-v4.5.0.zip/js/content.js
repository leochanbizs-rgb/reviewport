/**
 * Content Script - TikTok Shop Review Scraper v3.0
 *
 * Strategy (based on real DOM/JSON analysis):
 * 1. Page 1 reviews are embedded in <script id="__MODERN_ROUTER_DATA__"> as JSON.
 * 2. Subsequent pages load via XHR API -> captured by interceptor.js (MAIN world hook)
 *    which relays review JSON objects through window.postMessage.
 * 3. Pagination is driven by clicking the「下一個」/ "Next" div button.
 *
 * Review JSON fields (confirmed):
 *   reviewer_name, review_rating (1-5 int), review_text, review_time (ms timestamp),
 *   sku_specification, review_images[] (photo urls), review_id
 *
 * Output fields (user requirement): username, rating, description, sku, date, photo_urls
 */

(function () {
    if (window.__ttrhContentLoaded) {
        console.log('[ReviewPort] Content script already loaded');
        return;
    }
    window.__ttrhContentLoaded = true;

    // ==================== Interceptor injection (MAIN world) ====================
    function injectInterceptor() {
        try {
            const s = document.createElement('script');
            s.src = chrome.runtime.getURL('js/interceptor.js');
            s.onload = function () { this.remove(); };
            (document.head || document.documentElement).appendChild(s);
        } catch (e) {
            console.warn('[ReviewPort] Failed to inject interceptor:', e);
        }
    }
    // Inject as early as possible so the hook catches all review API calls
    if (document.documentElement) {
        injectInterceptor();
    } else {
        document.addEventListener('DOMContentLoaded', injectInterceptor, { once: true });
    }

    // ==================== Review store ====================
    const reviewStore = new Map(); // review_id -> normalized review
    let requiredNativeRating = 0; // exact native rating used for the current scan, or 0

    function tsToDate(ms) {
        try {
            const d = new Date(parseInt(ms, 10));
            if (isNaN(d.getTime())) return '';
            const y = d.getFullYear();
            const m = String(d.getMonth() + 1).padStart(2, '0');
            const day = String(d.getDate()).padStart(2, '0');
            return `${y}-${m}-${day}`;
        } catch (e) {
            return '';
        }
    }

    // Upgrade 300x300 thumbnails to larger images where possible
    function upgradePhotoUrl(url) {
        if (!url) return url;
        return url.replace(/-crop-webp:300:300\.webp/, '-crop-webp:800:800.webp');
    }

    function normalizeReview(raw) {
        if (!raw || !raw.review_id) return null;
        const photos = Array.isArray(raw.review_images) ? raw.review_images.map(upgradePhotoUrl) : [];
        return {
            review_id: String(raw.review_id),
            username: raw.reviewer_name || '',
            rating: parseInt(raw.review_rating, 10) || 0,
            description: (raw.review_text || '').replace(/\s+/g, ' ').trim(),
            sku: raw.sku_specification || '',
            date: tsToDate(raw.review_time),
            photo_urls: photos.join(' | ')
        };
    }

    function addReviews(rawList) {
        let added = 0;
        for (const raw of rawList) {
            const r = normalizeReview(raw);
            if (r && (!requiredNativeRating || r.rating === requiredNativeRating) && !reviewStore.has(r.review_id)) {
                reviewStore.set(r.review_id, r);
                added++;
            }
        }
        return added;
    }

    // ==================== Source 1: embedded SSR JSON (page 1) ====================
    function extractEmbeddedReviews() {
        const found = [];
        const script = document.getElementById('__MODERN_ROUTER_DATA__');
        if (!script) return found;
        try {
            const data = JSON.parse(script.textContent);
            (function walk(obj) {
                if (!obj || typeof obj !== 'object') return;
                if (Array.isArray(obj)) { obj.forEach(walk); return; }
                if (obj.review_id && (obj.review_text !== undefined || obj.review_rating !== undefined)) {
                    found.push(obj);
                    return;
                }
                Object.values(obj).forEach(walk);
            })(data);
        } catch (e) {
            console.warn('[ReviewPort] Failed to parse embedded JSON:', e);
        }
        return found;
    }

    // ==================== Source 2: intercepted API responses ====================
    window.addEventListener('message', (event) => {
        if (event.source !== window) return;
        const msg = event.data;
        if (!msg || msg.source !== 'ttrh-interceptor' || msg.type !== 'reviews-captured') return;
        const added = addReviews(msg.reviews);
        console.log(`[ReviewPort] Interceptor captured ${msg.reviews.length} reviews (${added} new). Total: ${reviewStore.size}`);
        if (scraper.isRunning) {
            scraper.onNewReviewsCaptured();
        }
    });

    // ==================== Pagination helpers ====================
    function findNextButton() {
        // Pagination buttons are divs; "下一個" (zh-TW), "下一个" (zh-CN), "Next" (en)
        const candidates = document.querySelectorAll('div, button');
        for (const el of candidates) {
            const text = (el.textContent || '').trim();
            if ((text === '下一個' || text === '下一个' || text === 'Next') && el.childElementCount <= 2) {
                return el;
            }
        }
        return null;
    }

    function getCurrentPageNumber() {
        // The active page button typically has distinct styling; fallback: parse from DOM
        const pagBtns = document.querySelectorAll('div');
        for (const el of pagBtns) {
            const text = (el.textContent || '').trim();
            if (/^\d+$/.test(text) && el.childElementCount === 0) {
                const cls = el.className || '';
                const style = window.getComputedStyle(el);
                // Active page usually has dark background or bold font
                if (style.backgroundColor && style.backgroundColor !== 'rgba(0, 0, 0, 0)' &&
                    style.backgroundColor !== 'rgb(255, 255, 255)') {
                    return parseInt(text, 10);
                }
            }
        }
        return null;
    }

    function isVisible(element) {
        if (!element) return false;
        const style = window.getComputedStyle(element);
        const rect = element.getBoundingClientRect();
        return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
    }

    /**
     * Detects an on-page verification prompt so scanning can stop safely.
     * It does not solve, click, or otherwise attempt to bypass verification.
     */
    function getVerificationMessage() {
        const verificationText = /captcha|security check|verify (that )?you(?:'|’)re human|verify your identity|安全驗證|安全验证|請完成驗證|请完成验证|拖動滑塊|拖动滑块|拼圖驗證|拼图验证/i;
        const candidates = document.querySelectorAll('[role="dialog"], [class*="captcha" i], [id*="captcha" i], [class*="verify" i], [id*="verify" i], [class*="challenge" i], [id*="challenge" i]');
        for (const element of candidates) {
            if (!isVisible(element)) continue;
            const text = (element.innerText || element.textContent || '').replace(/\s+/g, ' ').trim();
            if (verificationText.test(text)) return text.slice(0, 180);
        }
        return '';
    }

    function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

    function normalizedText(value) {
        return String(value || '').replace(/\s+/g, ' ').trim();
    }

    function normalizedNativeRating(value) {
        const text = normalizedText(value);
        if (/^(全部|all)$/i.test(text)) return 'all';
        return /^[1-5]$/.test(text) ? text : '';
    }

    /**
     * Locates TikTok's visible rating selector, not the rating-distribution bars.
     * The Tux select value is walked upward until it is next to the review-filter label.
     */
    function findNativeRatingSelect() {
        // TikTok's review-rating control has a dedicated review-filter container.
        const directValue = document.querySelector('[class*="review-filter-star-select-container"] [data-testid="tux-web-select"]');
        if (directValue) {
            return {
                valueNode: directValue,
                interactive: directValue.closest('[data-testid="tux-web-input-like"]')
                    || directValue.closest('[class*="tux-select"]')
                    || directValue
            };
        }

        // Conservative fallback for TikTok layout changes: only accept a select that
        // lives in a short filter-label container, never the broader review section.
        const values = document.querySelectorAll('[data-testid="tux-web-select"]');
        for (const valueNode of values) {
            let context = valueNode;
            for (let level = 0; context && level < 6; level++, context = context.parentElement) {
                const text = normalizedText(context.innerText || context.textContent);
                if (text.length < 120 && /(篩選條件|筛选条件|review filters?|filter)/i.test(text)) {
                    const interactive = valueNode.closest('[data-testid="tux-web-input-like"]')
                        || valueNode.closest('[class*="tux-select"]')
                        || valueNode;
                    return { valueNode, interactive };
                }
            }
        }
        return null;
    }

    function getNativeRatingSelection() {
        const select = findNativeRatingSelect();
        return select ? normalizedNativeRating(select.valueNode.innerText || select.valueNode.textContent) : '';
    }

    function findNativeRatingOption(target) {
        const expected = target === 'all' ? ['全部', 'All'] : [String(target)];
        const menuItems = document.querySelectorAll('.tux-menu-item, [data-testid="tux-web-interaction-container"]');
        for (const item of menuItems) {
            if (!isVisible(item)) continue;
            const text = normalizedText(item.innerText || item.textContent);
            if (expected.includes(text)) return item;
        }
        return null;
    }

    async function waitForCondition(predicate, timeout = 5000, interval = 120) {
        let waited = 0;
        while (waited < timeout) {
            if (predicate()) return true;
            await sleep(interval);
            waited += interval;
        }
        return Boolean(predicate());
    }

    /**
     * Applies TikTok's own exact-rating selector. The function only drives the
     * visible filter UI; it does not bypass verification or invoke private APIs.
     */
    async function applyNativeRatingFilter(targetRating) {
        const target = targetRating ? String(targetRating) : 'all';
        const select = findNativeRatingSelect();
        if (!select) {
            return { applied: false, changed: false, message: 'TikTok rating filter was not available; using local filtering.' };
        }

        let current = getNativeRatingSelection();
        const needsRefresh = target !== 'all' && current === target;
        const sequence = needsRefresh ? ['all', target] : (current === target ? [] : [target]);
        let changed = false;

        for (const step of sequence) {
            const freshSelect = findNativeRatingSelect();
            if (!freshSelect) {
                return { applied: false, changed, message: 'TikTok rating filter was unavailable while updating.' };
            }
            freshSelect.interactive.click();
            const optionReady = await waitForCondition(() => Boolean(findNativeRatingOption(step)), 1800);
            if (!optionReady) {
                return { applied: false, changed, message: 'TikTok rating choices did not open; using local filtering.' };
            }
            const option = findNativeRatingOption(step);
            if (!option) {
                return { applied: false, changed, message: 'Requested TikTok rating choice was not found.' };
            }
            option.click();
            const selected = await waitForCondition(() => getNativeRatingSelection() === step, 4000);
            if (!selected) {
                return { applied: false, changed, message: 'TikTok rating choice did not update; using local filtering.' };
            }
            changed = true;
            current = step;
            await sleep(250);
        }

        return { applied: current === target, changed, message: current === target ? `TikTok ${target === 'all' ? 'all-rating' : `${target}-star`} filter applied.` : 'Using local filtering.' };
    }

    // ==================== Scraper ====================
    const scraper = {
        isRunning: false,
        stopRequested: false,
        paused: false,
        resumePage: 1,
        lastCaptureTime: 0,
        options: { maxPages: 10, minStars: 1, maxStars: 5 },
        nativeRatingActive: false,

        setState(status, message, progress) {
            chrome.storage.local.set({
                scrapingState: {
                    status, // 'idle' | 'running' | 'paused' | 'completed' | 'error'
                    message: message || '',
                    progress: progress || 0,
                    reviewCount: reviewStore.size,
                    resumePage: this.resumePage,
                    timestamp: Date.now()
                }
            });
        },

        saveReviews() {
            chrome.storage.local.set({
                collectedReviews: Array.from(reviewStore.values()),
                lastUpdated: new Date().toISOString()
            });
        },

        onNewReviewsCaptured() {
            this.lastCaptureTime = Date.now();
            this.saveReviews();
        },

        async start(options) {
            if (this.isRunning) {
                console.log('[ReviewPort] Already running');
                return;
            }

            const requestedOptions = Object.assign({ maxPages: 10, minStars: 1, maxStars: 5, resume: false }, options || {});
            const maxPages = Math.max(1, parseInt(requestedOptions.maxPages, 10) || 10);
            const minStars = Math.max(1, Math.min(5, parseInt(requestedOptions.minStars, 10) || 1));
            const maxStars = Math.max(minStars, Math.min(5, parseInt(requestedOptions.maxStars, 10) || 5));
            const exactNativeRating = minStars === maxStars ? minStars : 0;
            const isResume = Boolean(requestedOptions.resume);
            if (!isResume) {
                reviewStore.clear();
                this.resumePage = 1;
                this.saveReviews();
            }

            this.isRunning = true;
            this.paused = false;
            this.stopRequested = false;
            this.options = { maxPages, minStars, maxStars };
            this.nativeRatingActive = false;
            requiredNativeRating = exactNativeRating;
            let page = Math.max(1, Math.min(maxPages, parseInt(this.resumePage, 10) || 1));
            if (isResume) {
                const visiblePage = getCurrentPageNumber();
                if (Number.isInteger(visiblePage) && visiblePage >= page && visiblePage <= maxPages) {
                    page = visiblePage;
                    this.resumePage = page;
                }
            }

            console.log(`[ReviewPort] 🚀 ${isResume ? 'Resuming' : 'Starting'} scan, maxPages=${maxPages}, from page ${page}`);
            this.setState('running', isResume ? `Resuming from page ${page}...` : 'Extracting page 1 reviews...', 5);

            if (document.readyState === 'loading') {
                await new Promise(r => document.addEventListener('DOMContentLoaded', r, { once: true }));
            }

            const initialVerification = getVerificationMessage();
            if (initialVerification) {
                this.pauseForVerification(page, maxPages, initialVerification);
                return;
            }

            if (!isResume) {
                this.setState('running', exactNativeRating
                    ? `Applying TikTok ${exactNativeRating}-star filter before scanning...`
                    : 'Preparing all-rating review results...', 5);
                const nativeResult = await applyNativeRatingFilter(exactNativeRating || null);
                const verificationAfterFilter = getVerificationMessage();
                if (verificationAfterFilter) {
                    this.pauseForVerification(page, maxPages, verificationAfterFilter);
                    return;
                }

                this.nativeRatingActive = Boolean(exactNativeRating && nativeResult.applied);
                if (this.nativeRatingActive) {
                    // The interceptor sees the filtered request. SSR JSON remains unfiltered,
                    // so it is intentionally not used for an exact native rating scan.
                    const receivedFilteredPage = await waitForCondition(() => reviewStore.size > 0, 5500, 150);
                    if (!receivedFilteredPage) {
                        this.pauseForNativeFilter(page, maxPages, exactNativeRating);
                        return;
                    }
                    this.saveReviews();
                    this.setState('running', `TikTok ${exactNativeRating}-star filter active: ${reviewStore.size} reviews collected`, Math.round((page / maxPages) * 100));
                } else {
                    // Fall back safely to the current local filtering behavior when the UI
                    // cannot provide a reliable native filtered response.
                    requiredNativeRating = 0;
                    console.warn('[ReviewPort] Native rating optimization unavailable:', nativeResult.message);
                }
            } else {
                this.nativeRatingActive = Boolean(exactNativeRating && getNativeRatingSelection() === String(exactNativeRating));
                if (!this.nativeRatingActive) requiredNativeRating = 0;
            }

            if (!this.nativeRatingActive) {
                // Page 1 data is embedded in the document for unfiltered/range scans.
                const embedded = extractEmbeddedReviews();
                const added = addReviews(embedded);
                console.log(`[ReviewPort] Page 1 embedded JSON: ${embedded.length} reviews (${added} new)`);
                this.saveReviews();
            }
            this.setState('running', `Page ${page}: ${reviewStore.size} reviews collected`, Math.round((page / maxPages) * 100));

            while (page < maxPages && !this.stopRequested) {
                const visibleVerification = getVerificationMessage();
                if (visibleVerification) {
                    this.pauseForVerification(page, maxPages, visibleVerification);
                    return;
                }

                const nextBtn = findNextButton();
                if (!nextBtn) {
                    console.log('[ReviewPort] No next button found, stopping pagination');
                    break;
                }

                const currentPage = page;
                const beforeCount = reviewStore.size;
                nextBtn.scrollIntoView({ block: 'center', behavior: 'instant' });
                await sleep(450);
                nextBtn.click();
                console.log(`[ReviewPort] Requested page ${currentPage + 1}`);

                let waited = 0;
                let verificationPrompt = '';
                while (waited < 8000) {
                    await sleep(400);
                    waited += 400;
                    verificationPrompt = getVerificationMessage();
                    if (verificationPrompt || reviewStore.size > beforeCount) break;
                }

                if (verificationPrompt) {
                    // Keep the last known safe page so a user-initiated resume does not skip data.
                    this.pauseForVerification(currentPage, maxPages, verificationPrompt);
                    return;
                }

                if (reviewStore.size === beforeCount) {
                    // Do not retry clicks. A challenge can be delayed or a page can have changed.
                    this.pauseForNoData(currentPage, maxPages);
                    return;
                }

                page = currentPage + 1;
                this.resumePage = page;
                this.saveReviews();
                this.setState('running',
                    `Page ${page}: ${reviewStore.size} reviews collected`,
                    Math.min(95, Math.round((page / maxPages) * 100)));
                await sleep(900); // conservative pacing; no anti-bot bypass attempt
            }

            this.saveReviews();
            this.isRunning = false;
            this.paused = false;
            console.log(`[ReviewPort] ✓ Completed: ${reviewStore.size} reviews from ${page} page(s)`);
            this.setState('completed', `Completed: ${reviewStore.size} reviews from ${page} page(s)`, 100);
        },

        pauseForVerification(page, maxPages, promptText) {
            this.resumePage = page;
            this.saveReviews();
            this.isRunning = false;
            this.paused = true;
            this.stopRequested = true;
            const progress = Math.min(95, Math.round((page / maxPages) * 100));
            console.warn('[ReviewPort] Paused for user verification:', promptText);
            this.setState('paused', `Paused: TikTok requires verification. Complete it in the page, then select Resume scan. ${reviewStore.size} reviews are safely saved.`, progress);
        },

        pauseForNativeFilter(page, maxPages, rating) {
            this.resumePage = page;
            this.saveReviews();
            this.isRunning = false;
            this.paused = true;
            this.stopRequested = true;
            const progress = Math.min(95, Math.round((page / maxPages) * 100));
            this.setState('paused', `Paused: TikTok did not return ${rating}-star results after applying its native filter. Check the page or complete verification, then select Resume scan.`, progress);
        },

        pauseForNoData(page, maxPages) {
            this.resumePage = page;
            this.saveReviews();
            this.isRunning = false;
            this.paused = true;
            this.stopRequested = true;
            const progress = Math.min(95, Math.round((page / maxPages) * 100));
            console.warn('[ReviewPort] Paused: no new reviews arrived after a page change');
            this.setState('paused', `Paused: no new review data arrived after page ${page}. If TikTok is showing verification, complete it, then select Resume scan.`, progress);
        },

        stop() {
            this.stopRequested = true;
            this.isRunning = false;
        },

        clear() {
            reviewStore.clear();
            this.resumePage = 1;
            this.paused = false;
            this.stopRequested = true;
            chrome.storage.local.remove(['collectedReviews', 'scrapingState']);
        }
    };

    // ==================== Message handling ====================
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        console.log('[ReviewPort] Content script received:', request.action);

        if (request.action === 'ping') {
            sendResponse({ success: true, loaded: true });
            return;
        }

        if (request.action === 'startScraping') {
            // Respond immediately; progress is reported via chrome.storage polling
            scraper.start(request.options);
            sendResponse({ success: true, started: true });
            return;
        }

        if (request.action === 'resumeScraping') {
            scraper.start(Object.assign({}, request.options || {}, { resume: true }));
            sendResponse({ success: true, started: true, resumed: true });
            return;
        }

        if (request.action === 'stopScraping') {
            scraper.stop();
            sendResponse({ success: true });
            return;
        }

        if (request.action === 'getReviews') {
            sendResponse({ success: true, reviews: Array.from(reviewStore.values()) });
            return;
        }

        if (request.action === 'clearReviews') {
            scraper.clear();
            sendResponse({ success: true });
            return;
        }
    });

    console.log('[ReviewPort] ReviewPort content script loaded');
})();
