/**
 * ReviewPort popup controller.
 * Review data is processed locally in Chrome. No AI, translation, or external
 * API service is used.
 */

const reviewFilter = new ReviewFilter();
const csvExporter = new CSVExporter();

let collectedReviews = [];
let processedReviews = [];
let pollInterval = null;

const minStarsSelect = document.getElementById('minStars');
const maxStarsSelect = document.getElementById('maxStars');
const maxPagesInput = document.getElementById('maxPages');
const onlyWithImagesCheckbox = document.getElementById('onlyWithImages');
const exportFormatSelect = document.getElementById('exportFormat');
const productHandleInput = document.getElementById('productHandle');
const judgeMeSettings = document.getElementById('judgeMeSettings');
const explorerExportNote = document.getElementById('explorerExportNote');
const explorerStatus = document.getElementById('explorerStatus');
const insightTotal = document.getElementById('insightTotal');
const insightPhotos = document.getElementById('insightPhotos');
const insightMultiPhotos = document.getElementById('insightMultiPhotos');
const insightLowRated = document.getElementById('insightLowRated');
const startScrapingBtn = document.getElementById('startScraping');
const resumeScrapingBtn = document.getElementById('resumeScraping');
const openFullPreviewBtn = document.getElementById('openFullPreview');
const exportCSVBtn = document.getElementById('exportCSV');
const clearDataBtn = document.getElementById('clearData');
const statusDiv = document.getElementById('status');
const connectionPill = document.getElementById('connectionPill');
const progressBar = document.getElementById('progressBar');
const reviewCountDiv = document.getElementById('reviewCount');
const previewContainer = document.getElementById('previewContainer');
const previewSummary = document.getElementById('previewSummary');
const progressElement = document.querySelector('.progress');

startScrapingBtn.addEventListener('click', () => startScraping(false));
resumeScrapingBtn.addEventListener('click', () => startScraping(true));
openFullPreviewBtn.addEventListener('click', openFullPreview);
exportCSVBtn.addEventListener('click', exportAsCSV);
clearDataBtn.addEventListener('click', clearData);
exportFormatSelect.addEventListener('change', saveAndRefresh);
productHandleInput.addEventListener('change', saveAndRefresh);
[minStarsSelect, maxStarsSelect, maxPagesInput, onlyWithImagesCheckbox]
    .forEach(element => element.addEventListener('change', saveAndRefresh));

chrome.storage.local.get([
    'minStars', 'maxStars', 'maxPages', 'onlyWithImages',
    'exportFormat', 'productHandle', 'collectedReviews', 'scrapingState'
], (result) => {
    if (result.minStars) minStarsSelect.value = result.minStars;
    if (result.maxStars) maxStarsSelect.value = result.maxStars;
    if (result.maxPages) maxPagesInput.value = result.maxPages;
    if (result.onlyWithImages !== undefined) onlyWithImagesCheckbox.checked = result.onlyWithImages;
    // Old stored "tiktok" choice is retired. Default to the single photo-separated CSV.
    exportFormatSelect.value = result.exportFormat === 'judgeme' ? 'judgeme' : 'explorer';
    if (result.productHandle) productHandleInput.value = result.productHandle;
    toggleExportSettings();

    if (Array.isArray(result.collectedReviews) && result.collectedReviews.length > 0) {
        collectedReviews = result.collectedReviews;
        applyFiltersOnly();
        exportCSVBtn.disabled = processedReviews.length === 0;
        openFullPreviewBtn.disabled = processedReviews.length === 0;
        updateStatus(`${processedReviews.length} matching reviews are ready to export.`, 'success');
    } else {
        updateInsights([]);
        openFullPreviewBtn.disabled = true;
        renderEmptyPreview('Your matching reviews will appear here after a scan.');
    }

    const activeState = result.scrapingState;
    const stateValue = activeState && (activeState.status || activeState.state);
    if (stateValue === 'paused') {
        handlePausedState(activeState);
    } else if (activeState && ['running', 'starting'].includes(stateValue)) {
        const age = Date.now() - activeState.timestamp;
        if (age < 60000) {
            startScrapingBtn.disabled = true;
            resumeScrapingBtn.hidden = true;
            updatePill('Scanning', 'running');
            startPolling();
        }
    }
});

function saveAndRefresh() {
    chrome.storage.local.set({
        minStars: minStarsSelect.value,
        maxStars: maxStarsSelect.value,
        maxPages: Math.max(1, Math.min(1802, parseInt(maxPagesInput.value, 10) || 10)),
        onlyWithImages: onlyWithImagesCheckbox.checked,
        exportFormat: exportFormatSelect.value,
        productHandle: productHandleInput.value.trim()
    });

    toggleExportSettings();
    if (collectedReviews.length) {
        applyFiltersOnly();
        exportCSVBtn.disabled = processedReviews.length === 0;
        openFullPreviewBtn.disabled = processedReviews.length === 0;
    }
}

function toggleExportSettings() {
    const isJudgeMe = exportFormatSelect.value === 'judgeme';
    judgeMeSettings.classList.toggle('is-hidden', !isJudgeMe);
    explorerExportNote.classList.toggle('is-hidden', isJudgeMe);
}

function updatePill(label, type = 'ready') {
    connectionPill.textContent = label;
    connectionPill.classList.toggle('is-running', type === 'running');
    connectionPill.classList.toggle('is-error', type === 'error');
    connectionPill.classList.toggle('is-paused', type === 'paused');
}

function updateStatus(message, type = 'info') {
    statusDiv.textContent = message;
    statusDiv.dataset.type = type;
    if (type === 'error') updatePill('Needs attention', 'error');
    else if (type === 'paused') updatePill('Paused', 'paused');
    else if (type === 'success') updatePill('Ready', 'ready');
    else if (type === 'running') updatePill('Scanning', 'running');
}

function handlePausedState(state) {
    stopPolling();
    startScrapingBtn.disabled = false;
    resumeScrapingBtn.hidden = false;
    resumeScrapingBtn.disabled = false;
    if (collectedReviews.length) {
        applyFiltersOnly();
        exportCSVBtn.disabled = processedReviews.length === 0;
        openFullPreviewBtn.disabled = processedReviews.length === 0;
    }
    updateProgress(state.progress || 0);
    updateStatus(
        state.message || 'Paused: complete TikTok verification in the page, then select Resume after verification.',
        'paused'
    );
}

function updateProgress(percentage) {
    const safePercentage = Math.max(0, Math.min(100, Number(percentage) || 0));
    progressBar.style.width = `${safePercentage}%`;
    progressElement.setAttribute('aria-valuenow', String(Math.round(safePercentage)));
}

function updateReviewCount() {
    const count = collectedReviews.length;
    reviewCountDiv.textContent = `${count} scanned`;
}

function updateInsights(reviews) {
    const summary = ReviewClassifier.summary(reviews);
    insightTotal.textContent = summary.total;
    insightPhotos.textContent = summary.photoReviews;
    insightMultiPhotos.textContent = summary.multiPhotoReviews;
    insightLowRated.textContent = summary.lowRated;
    explorerStatus.textContent = summary.total ? `${summary.total} ready` : 'Scan to explore';
}

function renderEmptyPreview(message) {
    previewContainer.innerHTML = `<p class="empty-state">${escapeHtml(message)}</p>`;
    previewSummary.textContent = 'No results';
}

function updatePreview() {
    if (processedReviews.length === 0) {
        renderEmptyPreview(collectedReviews.length
            ? 'No reviews match the current filter settings.'
            : 'Your matching reviews will appear here after a scan.');
        return;
    }

    previewSummary.textContent = `${processedReviews.length} match${processedReviews.length === 1 ? '' : 'es'}`;
    previewContainer.innerHTML = processedReviews.slice(0, 4).map(review => {
        const stars = '★'.repeat(Math.max(0, Math.min(5, Number(review.rating) || 0)));
        const excerpt = (review.description || 'No written review').replace(/\s+/g, ' ').trim();
        return `
            <article class="preview-item">
                <div class="preview-topline">
                    <span class="preview-name">${escapeHtml(review.username || 'Unknown reviewer')}</span>
                    <span class="rating" aria-label="${Number(review.rating) || 0} stars">${stars || '—'}</span>
                </div>
                <p class="text">${escapeHtml(excerpt.length > 145 ? `${excerpt.slice(0, 145).trim()}…` : excerpt)}</p>
            </article>`;
    }).join('');
}

function escapeHtml(value) {
    const element = document.createElement('div');
    element.textContent = String(value || '');
    return element.innerHTML;
}

function applyFiltersOnly() {
    const reviews = structuredClone(collectedReviews);
    processedReviews = reviewFilter.applyFilters(reviews, {
        minStars: Number(minStarsSelect.value),
        maxStars: Number(maxStarsSelect.value),
        onlyWithImages: onlyWithImagesCheckbox.checked,
        category: 'all'
    });
    updateReviewCount();
    updateInsights(processedReviews);
    updatePreview();
    chrome.storage.local.set({ processedReviews });
}

function startPolling() {
    if (pollInterval) clearInterval(pollInterval);
    pollInterval = setInterval(() => {
        chrome.storage.local.get(['scrapingState', 'collectedReviews'], (result) => {
            const state = result.scrapingState;
            if (!state) return;
            const stateValue = state.status || state.state;

            if (Array.isArray(result.collectedReviews)) {
                collectedReviews = result.collectedReviews;
                updateReviewCount();
            }

            updateProgress(state.progress);

            if (stateValue === 'paused') {
                handlePausedState(state);
            } else if (stateValue === 'completed') {
                stopPolling();
                onScrapingCompleted();
            } else if (stateValue === 'error') {
                stopPolling();
                startScrapingBtn.disabled = false;
                resumeScrapingBtn.hidden = true;
                updateStatus(state.message || 'The scan could not be completed.', 'error');
            } else {
                updateStatus(state.message || 'Scanning reviews…', 'running');
            }
        });
    }, 500);
}

function stopPolling() {
    if (pollInterval) clearInterval(pollInterval);
    pollInterval = null;
}

function onScrapingCompleted() {
    startScrapingBtn.disabled = false;
    resumeScrapingBtn.hidden = true;
    if (collectedReviews.length === 0) {
        updateProgress(0);
        updateStatus('No reviews found. Scroll to the review section and try again.', 'error');
        return;
    }

    applyFiltersOnly();
    updateProgress(100);
    exportCSVBtn.disabled = processedReviews.length === 0;
    openFullPreviewBtn.disabled = processedReviews.length === 0;
    updateStatus(`${processedReviews.length} matching reviews are ready to export.`, 'success');
}

async function startScraping(resume = false) {
    try {
        startScrapingBtn.disabled = true;
        resumeScrapingBtn.disabled = true;
        resumeScrapingBtn.hidden = true;
        if (!resume) {
            exportCSVBtn.disabled = true;
            openFullPreviewBtn.disabled = true;
        }
        updateProgress(resume ? 5 : 2);
        updateStatus(resume ? 'Checking the page after verification…' : 'Preparing the page for a scan…', 'running');

        await chrome.storage.local.set({
            scrapingState: {
                status: 'starting',
                progress: resume ? 5 : 0,
                message: resume ? 'Checking verification status…' : 'Preparing scan…',
                timestamp: Date.now()
            }
        });

        const [currentTab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (!currentTab) throw new Error('No active tab found.');
        if (!currentTab.url || !currentTab.url.includes('shop.tiktok.com')) {
            throw new Error('Open a TikTok Shop product page first.');
        }

        let pingOk = false;
        try {
            const pingResponse = await chrome.tabs.sendMessage(currentTab.id, { action: 'ping' });
            pingOk = Boolean(pingResponse && (pingResponse.loaded || pingResponse.pong));
        } catch (_) {
            pingOk = false;
        }

        if (!pingOk) {
            updateStatus('Connecting to the page…', 'running');
            await chrome.scripting.executeScript({
                target: { tabId: currentTab.id },
                files: ['js/content.js']
            });
            await new Promise(resolve => setTimeout(resolve, 500));
        }

        const maxPages = Math.max(1, Math.min(1802, parseInt(maxPagesInput.value, 10) || 10));
        const response = await chrome.tabs.sendMessage(currentTab.id, {
            action: resume ? 'resumeScraping' : 'startScraping',
            options: {
                maxPages,
                minStars: Number(minStarsSelect.value),
                maxStars: Number(maxStarsSelect.value)
            }
        });

        if (!response || !response.started) throw new Error('Review scan did not start. Refresh the product page and try again.');
        startPolling();
    } catch (error) {
        console.error('ReviewPort scan error:', error);
        updateProgress(0);
        updateStatus(error.message || 'Something went wrong while starting the scan.', 'error');
        startScrapingBtn.disabled = false;
        resumeScrapingBtn.disabled = false;
        stopPolling();
    }
}

async function openFullPreview() {
    if (!processedReviews.length && collectedReviews.length) applyFiltersOnly();
    if (!processedReviews.length) {
        updateStatus('Scan at least one matching review before opening the full preview.', 'error');
        return;
    }
    try {
        await chrome.tabs.create({ url: chrome.runtime.getURL('review-explorer.html') });
    } catch (error) {
        console.error('ReviewPort preview error:', error);
        updateStatus('Could not open the full review preview.', 'error');
    }
}

function exportAsCSV() {
    if (!processedReviews.length && collectedReviews.length) applyFiltersOnly();
    if (!processedReviews.length) {
        updateStatus('Nothing matches the current filters. Adjust the filters and try again.', 'error');
        return;
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, -5);
    const format = exportFormatSelect.value;

    try {
        if (format === 'judgeme') {
            const filename = `judge_me_reviews_${timestamp}.csv`;
            csvExporter.exportToJudgeMeCSV(processedReviews, filename, productHandleInput.value.trim() || 'tiktok-product');
            updateStatus(`Exported ${processedReviews.length} reviews as a Judge.me CSV.`, 'success');
        } else {
            const filename = `reviewport_reviews_${timestamp}.csv`;
            csvExporter.exportToExplorerCSV(processedReviews, filename);
            const photos = processedReviews.reduce((total, review) => total + ReviewClassifier.photoUrls(review).length, 0);
            updateStatus(`ReviewPort CSV exported: ${processedReviews.length} reviews, ${photos} photo URLs split into columns.`, 'success');
        }
    } catch (error) {
        console.error('ReviewPort export error:', error);
        updateStatus(`Export failed: ${error.message}`, 'error');
    }
}

function clearData() {
    if (!confirm('Clear all saved reviews from this browser?')) return;
    collectedReviews = [];
    processedReviews = [];
    resumeScrapingBtn.hidden = true;
    resumeScrapingBtn.disabled = false;
    updateProgress(0);
    updateReviewCount();
    updateInsights([]);
    renderEmptyPreview('Your matching reviews will appear here after a scan.');
    exportCSVBtn.disabled = true;
    openFullPreviewBtn.disabled = true;
    chrome.storage.local.remove([
        'collectedReviews', 'processedReviews', 'scrapingState', 'reviews', 'lastUpdated'
    ]);
    updateStatus('Saved reviews cleared from this browser.', 'success');
}

console.log('ReviewPort popup loaded');
